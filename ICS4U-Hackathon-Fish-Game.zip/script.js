window.addEventListener('load', function(){
  const canvas = document.getElementById('canvas1');
  const ctx = canvas.getContext('2d');
  canvas.width=800;
  canvas.height=720;

  class InputHandler {
    constructor(){
      this.keys = [];
      //Uses lexical scope to take arrow inputs and makes sure the inputs aren't already in the array
     window.addEventListener('keydown', e => {
      if (( e.key === 'ArrowDown' || 
            e.key === 'ArrowUp' || 
            e.key ==='ArrowLeft' || 
            e.key === 'ArrowRight')
            && this.keys.indexOf(e.key) === -1){
          this.keys.push(e.key);
        }
        //console.log(e.key, this.keys)
       //console.log(input)
      });
      //Once one of the four arrows are no longer being pressed down, they are removed from the array
      window.addEventListener('keyup', e => {
        if (e.key === 'ArrowDown' || 
            e.key === 'ArrowUp' || 
            e.key ==='ArrowLeft' || 
            e.key === 'ArrowRight'){
          this.keys.splice(this.keys.indexOf(e.key), 1);
        }
      });
    }
  }

  class Player {
    constructor(gameWidth, gameHeight){
      //Turns game width and game height into usable variables
      this.gameWidth = gameWidth;
      this.gameHeight = gameHeight;
      this.width = 200;
      this.height = 200;
      this.x = 200;
      this.y = gameHeight/2 - 100;
      this.image = document.getElementById('playerImage')
      this.speed = 0;
      this.speedY = 0
    } //Makes the entire rectangle white
    draw(context){ 
      context.fillStyle = 'white';
      context.fillRect(this.x, this.y, this.width, this.height);
      context.drawImage(this.image,this.x,this.y);
    }//When updating the rectangles position, move it right one pixel
    update(input){
      //horizontal movement
      if (input.keys.indexOf('ArrowRight') > -1 && input.keys.length < 2) {
        this.speed = 5;
      }  else if(input.keys.indexOf("ArrowLeft") > -1 && input.keys.length < 2) {
        this.speed = -5;
      } else if (input.keys.indexOf('ArrowUp') > -1 && input.keys.length < 2) {
        this.speedY = -5;
      } else if (input.keys.indexOf('ArrowDown') > -1 && input.keys.length < 2) {
        this.speedY = 5;
      }  
      else {
        this.speed = 0, this.speedY = 0;
      }
       this.x += this.speed; 
      if (this.x < 0) this.x = 0;
      else if (this.x > this.gameWidth - this.width) this.x = this.gameWidth - this.width;
      else if (this.y < 0) this.y = 0;
      else if (this.y > this.gameHeight - this.height) this.y = this.gameHeight - this.height;
      // Vertical Movement
      this.y += this.speedY;
    }
  }

  class Background {
   /* constructor(gameWidth, gameHeight){
      this.gameWidth = gameWidth;
      this.gameHeight = gameHeight;
      this.x = 0;
      this.y = 0;
      this.width = 2400;
      this.height = 720;
      this.speed = 20;
    }
    draw(context){
      context.drawImage(this.image, this.x, this.y, this.width, this.height);
    }
    update(){
      this.x -= this.speed;
    }*/
  }

  class Enemy {
    
  }

  function handleEnemies(){
    
  }

  function displayStatusText(){
    
  }

  const input = new InputHandler();
  const player = new Player(canvas.width, canvas.height);
  player.draw(ctx);
  player.update(input);
  //const background = newBackground(canvas.width, canvas.height);


function animate(){
  //Only shows the most recent frame
  ctx.clearRect(0,0,canvas.width,canvas.height);
  //Draws the new position of the player infinitely
  player.draw(ctx);
  player.update(input);
  requestAnimationFrame(animate);
}
  //Calls the function to draw the player
  animate();

});